[EN]
Il faut placer le fichier WebexAntiFlash.dll dans le dossier où se trouve l'exécutable atmgr.exe. Il est généralement situé à l'emplacement suivant:
C:\Users\USERNAME_HERE\AppData\Local\WebEx\WebEx\Meetings
Vous pouvez ensuite placer le fichier WebexInjector.exe à l'endroit de votre choix.
Après avoir rejoint une réunion, lancez simplement WebexInjector.exe et attendez qu'une boîte de dialogue s'affiche.

[FR]
The WebexAntiFlash.dll file must be placed in the folder containing atmgr.exe, which is generally the following:
C:\Users\USERNAME_HERE\AppData\Local\WebEx\WebEx\Meetings
You can then copy the WebexInjector.exe file wherever you'd like.
After joining a Webex meeting, simply start WebexInjector.exe and wait for a dialog box to tell you it has started!